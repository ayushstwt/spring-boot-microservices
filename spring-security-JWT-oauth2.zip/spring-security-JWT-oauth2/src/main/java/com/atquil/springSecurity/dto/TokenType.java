package com.atquil.springSecurity.dto;

/**
 * @author atquil
 */
public enum TokenType {
    Bearer
}
